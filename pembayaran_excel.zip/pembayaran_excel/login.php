<?php include 'config.php';
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $res = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
    $user = mysqli_fetch_assoc($res);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        header("Location: " . ($user['role'] == 'admin' ? 'admin_dashboard.php' : 'mhs_dashboard.php'));
    } else {
        $error = "Username atau Password Salah!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | UAS-Pay Digital</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body class="flex items-center justify-center p-6">

    <div class="glass-card p-10 w-full max-w-md">
        <div class="text-center mb-10">
            <h2 class="text-3xl font-black text-white tracking-tighter">PORTAL UAS.👋</h2>
            <p class="text-white/60 text-sm mt-1 uppercase tracking-widest">Sistem Pembayaran</p>
        </div>
        
        <?php if(isset($error)): ?>
            <div class="bg-red-500/20 text-red-100 p-3 rounded-xl mb-6 text-sm text-center border border-red-500/30">
                <?= $error ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            <div>
                <input type="text" name="username" class="w-full p-4 rounded-xl shadow-inner" placeholder="Masukkan NIM / Username" required>
            </div>
            <div>
                <input type="password" name="password" class="w-full p-4 rounded-xl shadow-inner" placeholder="Masukkan Password" required>
            </div>
            <button type="submit" name="login" class="btn-primary w-full py-4 rounded-xl shadow-lg">
                Masuk Sekarang
            </button>
        </form>
        
        <div class="mt-8 pt-6 border-t border-white/10 text-center text-sm">
            <p class="text-white/60 text-center">Belum memiliki akun?</p>
            <a href="register.php" class="text-white font-bold hover:underline">Daftar Akun Baru</a>
        </div>
    </div>

</body>
</html>
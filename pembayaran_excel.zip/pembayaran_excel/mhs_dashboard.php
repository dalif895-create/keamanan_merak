<?php 
include 'config.php';

// Proteksi Halaman
if ($_SESSION['role'] != 'mahasiswa') {
    header("Location: login.php");
    exit();
}
$uid = $_SESSION['user_id'];

// Logika Simpan Pembayaran
if (isset($_POST['bayar'])) {
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $metode = $_POST['metode'];
    $jumlah = $_POST['jumlah'];
    $kode_bayar = $_POST['kode_bayar']; 
    
    $bukti = time() . "_" . $_FILES['bukti']['name'];
    if(move_uploaded_file($_FILES['bukti']['tmp_name'], "uploads/".$bukti)) {
        mysqli_query($conn, "INSERT INTO pembayaran (mahasiswa_id, nim, nama_lengkap, metode, jumlah, kode_bayar, bukti_bayar) 
                             VALUES ('$uid', '$nim', '$nama', '$metode', '$jumlah', '$kode_bayar', '$bukti')");
        echo "<script>alert('Pembayaran Berhasil Terkirim!'); window.location='mhs_dashboard.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Pembayaran UAS | QRIS Center</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
    <style>
        .qris-stand {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.3);
            border-top: 10px solid #dc2626; /* Warna Merah QRIS */
            position: relative;
        }
        .qris-logo { width: 80px; margin-bottom: 10px; }
        .scan-line {
            position: absolute;
            width: 100%; height: 3px;
            background: #4f46e5; top: 0; left: 0;
            box-shadow: 0 0 15px #4f46e5;
            animation: moveScan 3s linear infinite;
            display: none;
        }
        @keyframes moveScan { 0% { top: 0; } 50% { top: 100%; } 100% { top: 0; } }
    </style>
</head>
<body class="p-4">

    <div class="max-w-6xl mx-auto">
        <header class="glass-card p-6 mb-8 flex justify-between items-center">
            <h1 class="text-2xl font-black text-white italic">UAS-PAY SYSTEM.👋</h1>
            <a href="logout.php" class="bg-red-500 text-white px-5 py-2 rounded-lg font-bold text-xs hover:bg-red-600 transition">LOGOUT</a>
        </header>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            <div class="glass-card p-8">
                <h2 class="text-white font-bold text-xl mb-6 border-b border-white/10 pb-2">INPUT DATA TRANSAKSI</h2>
                <form method="POST" enctype="multipart/form-data" class="space-y-4">
                    <input type="text" name="nim" placeholder="Masukkan NIM" class="w-full p-4 rounded-xl" required>
                    <input type="text" name="nama" placeholder="Nama Mahasiswa" class="w-full p-4 rounded-xl" required>
                    
                    <div>
                        <label class="text-white/70 text-[10px] font-bold ml-1 uppercase">Nominal Pembayaran (Rp)</label>
                        <input type="number" id="input_jumlah" name="jumlah" oninput="generateQR()" placeholder="Contoh: 500000" class="w-full p-4 rounded-xl mt-1 text-lg font-bold text-indigo-900" required>
                    </div>

                    <select name="metode" class="w-full p-4 rounded-xl cursor-pointer">
                        <option value="barcode">QRIS / Barcode (Scan Samping)</option>
                        <option value="mbanking">Transfer Mobile Banking</option>
                    </select>

                    <input type="text" name="kode_bayar" placeholder="Nomor Referensi / ID Transaksi" class="w-full p-4 rounded-xl border-2 border-dashed border-white/30" required>
                    
                    <div class="bg-white/5 p-4 rounded-xl border border-white/10">
                        <label class="text-white/60 text-xs block mb-2 font-bold uppercase tracking-widest">Lampirkan Bukti Bayar</label>
                        <input type="file" name="bukti" class="w-full text-white text-xs" required>
                    </div>

                    <button type="submit" name="bayar" class="btn-primary w-full py-4 rounded-xl shadow-2xl font-black tracking-widest">KONFIRMASI PEMBAYARAN</button>
                </form>
            </div>

            <div class="flex flex-col items-center justify-center space-y-4">
                <div class="qris-stand w-full max-w-[350px] text-center">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/a/a2/Logo_QRIS.svg" class="qris-logo mx-auto">
                    <p class="text-xs font-bold text-gray-800">NAMA MERCHANT: KAMPUS UAS-PAY</p>
                    <p class="text-[10px] text-gray-400 mb-4">NMID: ID1234567890</p>
                    
                    <div class="relative bg-gray-100 p-4 rounded-lg overflow-hidden border-2 border-gray-200">
                        <div id="scanner_line" class="scan-line"></div>
                        <img id="qr_image" src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=SILAKAN_INPUT_NOMINAL" class="w-full aspect-square object-contain">
                    </div>

                    <div id="display_harga" class="mt-4 p-3 bg-indigo-50 rounded-lg hidden">
                        <p class="text-[10px] text-indigo-400 uppercase font-bold">Total yang harus dibayar:</p>
                        <p id="total_text" class="text-xl font-black text-indigo-900">Rp 0</p>
                    </div>

                    <p class="mt-4 text-[9px] text-gray-400 uppercase leading-tight font-medium">Dicetak oleh: Universitas Sistem Pembayaran<br>Satu QRIS untuk Semua</p>
                </div>
                
                <div class="glass-card p-4 w-full max-w-[350px] text-center">
                    <p class="text-white/60 text-[10px] italic font-medium">"Masukkan nominal harga di samping, scan QR Code di atas, lalu bayar menggunakan e-wallet Anda."</p>
                </div>
            </div>

        </div>
    </div>

    <script>
    function generateQR() {
        const jumlah = document.getElementById('input_jumlah').value;
        const qrImg = document.getElementById('qr_image');
        const displayHarga = document.getElementById('display_harga');
        const totalText = document.getElementById('total_text');
        const scanLine = document.getElementById('scanner_line');

        if(jumlah > 0) {
            // Mengubah URL QR Code untuk menyisipkan nominal (Dinamis)
            qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=UAS_PAY_GATEWAY_RP_${jumlah}`;
            
            // Tampilkan Detail Harga & Animasi Scanner
            displayHarga.classList.remove('hidden');
            scanLine.style.display = 'block';
            totalText.innerText = "Rp " + new Intl.NumberFormat('id-ID').format(jumlah);
        } else {
            qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=SILAKAN_INPUT_NOMINAL`;
            displayHarga.classList.add('hidden');
            scanLine.style.display = 'none';
        }
    }
    </script>
</body>
</html>
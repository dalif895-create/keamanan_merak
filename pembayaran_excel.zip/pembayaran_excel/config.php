<?php
$conn = mysqli_connect("localhost", "root", "", "pembayaran_uas");
if (!$conn) { die("Koneksi Gagal: " . mysqli_connect_error()); }
session_start();
?>